package dao;

import java.sql.SQLException;
import java.util.List;

public interface AbstractDao<T> {

    List<T> findAll() throws SQLException;

    T findOnId(Integer id) throws SQLException;

    T add(T entity) throws SQLException;

    T update(T entity) throws SQLException;

    void delete(int id) throws SQLException;

    void deleteOnId(int id) throws SQLException;
}

