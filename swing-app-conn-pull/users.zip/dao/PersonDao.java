package dao;

import database.ConnectionPool;
import model.User;
import java.sql.*;
import java.util.List;

public class PersonDao implements AbstractDao<User>{

    private static final String CREATE_NEW_PERSON_RETURN_PERSON_ID =  "INSERT INTO person (person_id, first_name, last_name, address) VALUES (nextval('person_sequence'), ?, ?, ?)";
    private static final String UPDATE_PERSON = "UPDATE person SET first_name = ?, last_name = ?, address = ? WHERE person_id = ?";
    private static final String DELETE_PERSON = "DELETE FROM person WHERE person_id = ?";

    public int addPerson(User user) throws SQLException {
        ConnectionPool connectionPool = null;
        PreparedStatement statement = null;
        Connection connection = null;
        ResultSet resultSet = null;
        int primaryKey = 0;
        try {
            connectionPool = ConnectionPool.getInstance();
            connection = connectionPool.getConnection();
            statement = connection.prepareStatement(CREATE_NEW_PERSON_RETURN_PERSON_ID, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, user.getFirstName() );
            statement.setString(2, user.getLastName());
            statement.setString(3, user.getAddress());
            statement.executeUpdate();
            resultSet = statement.getGeneratedKeys();
            if (resultSet.next()) {
                primaryKey = (int) resultSet.getLong(1);
            }
            else {
                throw new SQLException("Creating person failed, no ID obtained.");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            statement.close();
            resultSet.close();
            connectionPool.releaseConnection(connection);
        }
        return primaryKey;
    }

    @Override
    public User update(User user) throws SQLException {
        ConnectionPool connectionPool = null;
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connectionPool = ConnectionPool.getInstance();
            connection = connectionPool.getConnection();
            statement = connection.prepareStatement(UPDATE_PERSON);
            statement.setString(1, user.getFirstName());
            statement.setString(2, user.getLastName());
            statement.setString(3, user.getAddress());
            statement.setInt(4, user.getId());
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            statement.close();
            connectionPool.releaseConnection(connection);
        }
        return user;
    }

    @Override
    public void deleteOnId(int personId) throws SQLException {
        ConnectionPool connectionPool = null;
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connectionPool = ConnectionPool.getInstance();
            connection = connectionPool.getConnection();
            statement = connection.prepareStatement(DELETE_PERSON);
            statement.setInt(1, personId);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            statement.close();
            connectionPool.releaseConnection(connection);
        }
    }

    @Override
    public List<User> findAll() throws SQLException {
        return null;
    }

    @Override
    public User findOnId(Integer id) throws SQLException {
        return null;
    }

    @Override
    public User add(User entity) throws SQLException {
        return null;
    }

    @Override
    public void delete(int id) throws SQLException {

    }


}
