package dao;

import database.ConnectionPool;
import model.Person;
import model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDao implements AbstractDao<User>{

    private static final String SELECT_ALL_FROM_USERS = "SELECT u.user_id, u.username, u.password, u.id_person, p.first_name, p.last_name, p.address "
            + "FROM users u JOIN person p on u.id_person = p.person_id;";
    private static final String SELECT_ONE_FROM_USERS = "SELECT * FROM person INNER JOIN users ON person.person_id = users.id_person WHERE users.user_id = ?";
    private static final String CREATE_NEW_USER = "INSERT INTO users (user_id, username, password, id_person) VALUES (nextval('users_sequence')  , ?, ?, ?)";
    private static final String UPDATE_USER = "UPDATE users SET username = ?, password = ? WHERE user_id = ?";
    private static final String SELECT_PERSON_ID_FROM_PERSON = "SELECT * FROM person INNER JOIN users ON person.person_id = users.id_person WHERE users.user_id = ?";
    private static final String DELETE_USER_ON_ID = "DELETE FROM users WHERE user_id = ?";

    PersonDao personDao = new PersonDao();

    @Override
    public List<User> findAll() throws SQLException {
        List<User> users = new ArrayList<>();
        ConnectionPool connectionPool = null;
        PreparedStatement statement = null;
        Connection connection = null;
        try {
            connectionPool = ConnectionPool.getInstance();
            connection = connectionPool.getConnection();
            statement = connection.prepareStatement(SELECT_ALL_FROM_USERS);
            ResultSet rs = statement.executeQuery();
            while (rs.next()) {
                User user = new User();
                user.setId(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setFirstName(rs.getString("first_name"));
                user.setLastName(rs.getString("last_name"));
                user.setAddress(rs.getString("address"));
                users.add(user);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            statement.close();
            connectionPool.releaseConnection(connection);
        }
        return users;
    }

    @Override
    public User findOnId(Integer id) throws SQLException {
        ConnectionPool connectionPool = null;
        PreparedStatement statement = null;
        Connection connection = null;
        User user = new User();
        try {
            connectionPool = ConnectionPool.getInstance();
            connection = connectionPool.getConnection();
            statement = connection.prepareStatement(SELECT_ONE_FROM_USERS);
            statement.setInt(1, id);
            user = setUserData(statement);
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            statement.close();
            connectionPool.releaseConnection(connection);
        }
        return user;
    }

    public User setUserData(PreparedStatement statement) throws SQLException {
        ResultSet rs = statement.executeQuery();
        User user = new User();
        Person person = new Person();
        while(rs.next()) {
            person.setFirstName(rs.getString("first_name"));
            person.setLastName(rs.getString("last_name"));
            person.setAddress(rs.getString("address"));
            user.setUsername(rs.getString("username"));
            user.setPassword(rs.getString("password"));
            user.setFirstName(person.getFirstName());
            user.setLastName(person.getLastName());
            user.setAddress(person.getAddress());
        }
        return user;
    }

    @Override
    public User add(User user) throws SQLException {
        ConnectionPool connectionPool = null;
        PreparedStatement statement = null;
        Connection connection = null;
        int personId = personDao.addPerson(user);
        try {
            connectionPool = ConnectionPool.getInstance();
            connection = connectionPool.getConnection();
            statement = connection.prepareStatement(CREATE_NEW_USER);
            statement.setString(1, user.getUsername());
            statement.setString(2, user.getPassword());
            statement.setInt(3, personId);
            statement.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            statement.close();
            connectionPool.releaseConnection(connection);
        }
        return user;
    }

    @Override
    public User update(User user) throws SQLException {
        ConnectionPool connectionPool = null;
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            personDao.update(user);
            connectionPool = ConnectionPool.getInstance();
            connection = connectionPool.getConnection();
            statement = connection.prepareStatement(UPDATE_USER);
            statement.setString(1, user.getUsername());
            statement.setString(2, user.getPassword());
            statement.setInt(3, user.getId());
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            statement.close();
            connectionPool.releaseConnection(connection);
        }
        return user;
    }

    @Override
    public void delete(int userId) throws SQLException {
        ConnectionPool connectionPool = null;
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        int personId = 0;
        try {
            connectionPool = ConnectionPool.getInstance();
            connection = connectionPool.getConnection();
            statement = connection.prepareStatement(SELECT_PERSON_ID_FROM_PERSON);
            statement.setInt(1, userId);
            resultSet = statement.executeQuery();
            while(resultSet.next()) {
                personId = Integer.parseInt(resultSet.getString("id_person"));
            }
            personDao.deleteOnId(personId);
            deleteOnId(userId);
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            statement.close();
            resultSet.close();
            connectionPool.releaseConnection(connection);
        }
    }

    @Override
    public void deleteOnId(int userId) throws SQLException {
        ConnectionPool connectionPool = null;
        Connection connection = null;
        PreparedStatement statement = null;
        try {
            connectionPool = ConnectionPool.getInstance();
            connection = connectionPool.getConnection();
            statement = connection.prepareStatement(DELETE_USER_ON_ID);
            statement.setInt(1, userId);
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            statement.close();
            connectionPool.releaseConnection(connection);
        }
    }
}
