DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS person;

create table person(
  person_id SERIAL PRIMARY KEY,
  first_name varchar(30),
  last_name varchar(40),
  address varchar(50)
);

create table users(
  user_id SERIAL PRIMARY KEY,
  username varchar(30),
  password varchar(50),
  id_person int,
  FOREIGN KEY(id_person) REFERENCES person(person_id) ON DELETE CASCADE
);

CREATE SEQUENCE person_sequence start 8 increment 1;
CREATE SEQUENCE users_sequence start 8 increment 1;

INSERT INTO person (person_id, first_name, last_name, address) VALUES (1, 'firstName1', 'lastName1', 'address1');
INSERT INTO person (person_id, first_name, last_name, address) VALUES (2, 'firstName2', 'lastName2', 'address2');
INSERT INTO person (person_id, first_name, last_name, address) VALUES (3, 'firstName3', 'lastName3', 'address3');
INSERT INTO person (person_id, first_name, last_name, address) VALUES (4, 'firstName4', 'lastName4', 'address4');
INSERT INTO person (person_id, first_name, last_name, address) VALUES (5, 'firstName5', 'lastName5', 'address5');
INSERT INTO person (person_id, first_name, last_name, address) VALUES (6, 'firstName6', 'lastName6', 'address6');
INSERT INTO person (person_id, first_name, last_name, address) VALUES (7, 'firstName7', 'lastName7', 'address7');

INSERT INTO users (user_id, username, password, id_person) VALUES (1,	'user1', 'password1', 1);
INSERT INTO users (user_id, username, password, id_person) VALUES (2,	'user2', 'password2', 2);
INSERT INTO users (user_id, username, password, id_person) VALUES (3,	'user3', 'password3', 3);
INSERT INTO users (user_id, username, password, id_person) VALUES (4,	'user4', 'password4', 4);
INSERT INTO users (user_id, username, password, id_person) VALUES (5,	'user5', 'password5', 5);
INSERT INTO users (user_id, username, password, id_person) VALUES (6,	'user6', 'password6', 6);
INSERT INTO users (user_id, username, password, id_person) VALUES (7,	'user7', 'password6', 7);
	