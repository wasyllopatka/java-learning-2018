//package model;
//
//import database.ConnectionPool;
//
//import java.sql.*;
//
//public class Program {
//
//    // Create user
//    public void add(User user) throws SQLException {
////        ConnectionPool connectionPool = null;
////        PreparedStatement statement = null;
////        Connection connection = null;
////        int personId = createPerson(user);
////        try {
////            connectionPool = ConnectionPool.getInstance();
////            connection = connectionPool.getConnection();
////            statement = connection.prepareStatement(
////                    "INSERT INTO users (user_id, username, password, id_person) VALUES (nextval('users_sequence')  , ?, ?, ?)");
////            statement.setString(1, user.getUsername());
////            statement.setString(2, user.getPassword());
////            statement.setInt(3, personId);
////            statement.executeUpdate();
////
////        } catch (SQLException ex) {
////            ex.printStackTrace();
////        } finally {
////            statement.close();
////            connectionPool.releaseConnection(connection);
////        }
//    }
//
//    // Create person
//    public int createPerson(User user) throws SQLException {
////        ConnectionPool connectionPool = null;
////        PreparedStatement statement = null;
////        Connection connection = null;
////        ResultSet resultSet = null;
////        int primaryKey = 0;
////        try {
////            connectionPool = ConnectionPool.getInstance();
////            connection = connectionPool.getConnection();
////
////            statement = connection.prepareStatement(
////                    "INSERT INTO person (person_id, first_name, last_name, address) VALUES (nextval('person_sequence'), ?, ?, ?)",
////                            Statement.RETURN_GENERATED_KEYS);
////            statement.setString(1, user.getFirstName() );
////            statement.setString(2, user.getLastName());
////            statement.setString(3, user.getAddress());
////            statement.executeUpdate();
////
////            resultSet = statement.getGeneratedKeys();
////            if (resultSet.next()) {
////                primaryKey = (int) resultSet.getLong(1);
////            }
////            else {
////                throw new SQLException("Creating person failed, no ID obtained.");
////            }
////        } catch (SQLException ex) {
////            ex.printStackTrace();
////        } finally {
////            statement.close();
////            resultSet.close();
////            connectionPool.releaseConnection(connection);
////        }
////        return primaryKey;
//    }
//
//    // Get user on id
////    public User findOnId(int id) throws SQLException {
////        ConnectionPool connectionPool = null;
////        PreparedStatement statement = null;
////        Connection connection = null;
////        User user = new User();
////        try {
////            connectionPool = ConnectionPool.getInstance();
////            connection = connectionPool.getConnection();
////            statement = connection.prepareStatement(
////                    "SELECT * FROM person INNER JOIN users ON person.person_id = users.id_person WHERE users.user_id = ?" );
////            statement.setInt(1, id);
////            user = setUserData(statement);
////        } catch (SQLException ex) {
////            ex.printStackTrace();
////        } finally {
////            statement.close();
////            connectionPool.releaseConnection(connection);
////        }
////        return user;
////    }
//
////    // Update person
////    public User update(User user) throws SQLException {
////        ConnectionPool connectionPool = null;
////        Connection connection = null;
////        PreparedStatement statement = null;
////        try {
////            connectionPool = ConnectionPool.getInstance();
////            connection = connectionPool.getConnection();
////            statement = connection.prepareStatement(
////                    "UPDATE person SET first_name = ?, last_name = ?, address = ? WHERE person_id = ?");
////            statement.setString(1, user.getFirstName());
////            statement.setString(2, user.getLastName());
////            statement.setString(3, user.getAddress());
////            statement.setInt(4, user.getId());
////            statement.executeUpdate();
////        } catch (SQLException ex) {
////            ex.printStackTrace();
////        } finally {
////            statement.close();
////            connectionPool.releaseConnection(connection);
////        }
////        return user;
////    }
//
//    // Update user
//    public User updatePerson(User user) throws SQLException {
////        ConnectionPool connectionPool = null;
////        Connection connection = null;
////        PreparedStatement statement = null;
////        try {
////            update(user);
////            connectionPool = ConnectionPool.getInstance();
////            connection = connectionPool.getConnection();
////            statement = connection.prepareStatement
////                    ("UPDATE users SET username = ?, password = ? WHERE user_id = ?");
////            statement.setString(1, user.getUsername());
////            statement.setString(2, user.getPassword());
////            statement.setInt(3, user.getId());
////            statement.executeUpdate();
////        } catch (SQLException ex) {
////            ex.printStackTrace();
////        } finally {
////            statement.close();
////            connectionPool.releaseConnection(connection);
////        }
////        return user;
//    }
//
//    // Helper method for GetUserOnId
////    public User setUserData(PreparedStatement statement) throws SQLException {
////        ResultSet rs = statement.executeQuery();
////        User user = new User();
////        Person person = new Person();
////        while(rs.next()) {
////            person.setFirstName(rs.getString("first_name"));
////            person.setLastName(rs.getString("last_name"));
////            person.setAddress(rs.getString("address"));
////            user.setUsername(rs.getString("username"));
////            user.setPassword(rs.getString("password"));
////            user.setFirstName(person.getFirstName());
////            user.setLastName(person.getLastName());
////            user.setAddress(person.getAddress());
////        }
////        return user;
////    }
//
//    // Delete user head method
//    public void deleteUser(int userId) {
////        ConnectionPool connectionPool = ConnectionPool.getInstance();
////        Connection connection = connectionPool.getConnection();
////        int personId = 0;
////        try {
////            PreparedStatement statement = connection.prepareStatement(
////                    "SELECT * FROM person INNER JOIN users ON person.person_id = users.id_person WHERE users.user_id = ?" );
////            statement.setInt(1, userId);
////            ResultSet rs = statement.executeQuery();
////            while(rs.next()) {
////                personId = Integer.parseInt(rs.getString("id_person"));
////            }
////            deletePersonOnId(personId);
////            deleteUserOnId(userId);
////        } catch (SQLException ex) {
////            ex.printStackTrace();
////        }
//    }
//
//    // Delete person on id
////    public void deletePersonOnId(int personId) {
////        ConnectionPool connectionPool = ConnectionPool.getInstance();
////        Connection connection = connectionPool.getConnection();
////        try {
////            PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM person WHERE person_id = ? ");
////            preparedStatement.setInt(1, personId);
////            preparedStatement.executeUpdate();
////            preparedStatement.close();
////        } catch (SQLException ex) {
////            ex.printStackTrace();
////        }
////    }
//    // Delete user on id
////    public void deleteUserOnId(int userId) {
////        ConnectionPool connectionPool = ConnectionPool.getInstance();
////        Connection connection = connectionPool.getConnection();
////        try {
////            PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM users WHERE user_id = ? ");
////            preparedStatement.setInt(1, userId);
////            preparedStatement.executeUpdate();
////            preparedStatement.close();
////        } catch (SQLException ex) {
////            ex.printStackTrace();
////        }
////    }
//}
