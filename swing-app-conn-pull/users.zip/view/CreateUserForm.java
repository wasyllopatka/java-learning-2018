package view;

import dao.UserDao;
import model.User;
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class CreateUserForm extends JPanel{
    UserDao userDao = new UserDao();
    SwingUtils utils = new SwingUtils();
    JTextField firstNameTF = new JTextField(12);
    JTextField lastNameTF = new JTextField(12);
    JTextField addressTF = new JTextField(12);
    JTextField usernameTF = new JTextField(12);
    JTextField passwordTF = new JTextField(12);
    JButton createBtn = new JButton("Create");

    public CreateUserForm() {

        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(2, 2, 2, 2);

        addComponents(new JLabel("First name"), firstNameTF, this, gbc);
        addComponents(new JLabel("Last name"), lastNameTF, this, gbc);
        addComponents(new JLabel("Address"), addressTF, this, gbc);
        addComponents(new JLabel("Username"), usernameTF, this, gbc);
        addComponents(new JLabel("Password"), passwordTF, this, gbc);
        add(createBtn);
        createBtn.addActionListener(e -> {
            try {
                userDao.add(setUser());
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            JOptionPane.showMessageDialog(this,"User created successfully!");
            utils.disposePanel(this);
            try {
                new Menu();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        });
    }

    private void addComponents(JLabel label, JTextField tf, JPanel p, GridBagConstraints gbc) {
        gbc.anchor = GridBagConstraints.EAST;
        gbc.gridwidth = GridBagConstraints.RELATIVE;
        p.add(label, gbc);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        p.add(tf, gbc);
    }

    public User setUser() {
        User user = new User();
        user.setFirstName(firstNameTF.getText());
        user.setLastName(lastNameTF.getText());
        user.setAddress(addressTF.getText());
        user.setUsername(usernameTF.getText());
        user.setPassword(passwordTF.getText());
        return user;
    }
}
