package view;

import dao.UserDao;
import model.User;
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class EditUserForm extends JPanel {
    UserDao userDao = new UserDao();
    SwingUtils utils = new SwingUtils();

    JTextField firstNameTF = new JTextField(12);
    JTextField lastNameTF = new JTextField(12);
    JTextField addressTF = new JTextField(12);
    JTextField usernameTF = new JTextField(12);
    JTextField passwordTF = new JTextField(12);
    JButton saveBtn = new JButton("Save");

    public EditUserForm(int userID) throws SQLException {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(2, 2, 2, 2);
        addComponents(new JLabel("First name"), firstNameTF, this, gbc);
        addComponents(new JLabel("Last name"), lastNameTF, this, gbc);
        addComponents(new JLabel("Address"), addressTF, this, gbc);
        addComponents(new JLabel("Username"), usernameTF, this, gbc);
        addComponents(new JLabel("Password"), passwordTF, this, gbc);
        setEditFields(userID);

        add(saveBtn);
        saveBtn.addActionListener(e -> {
            try {
                userDao.update(this.getEditFields(userID));
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            JOptionPane.showMessageDialog(this,"User saved successfully!");
            utils.disposePanel(this);
            try {
                new Menu();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
        });
    }

    private void addComponents(JLabel label, JTextField tf, JPanel p, GridBagConstraints gbc) {
        gbc.anchor = GridBagConstraints.EAST;
        gbc.gridwidth = GridBagConstraints.RELATIVE;
        p.add(label, gbc);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        p.add(tf, gbc);
    }

    public User setEditFields(int userId) throws SQLException {
        User user = userDao.findOnId(userId);
        firstNameTF.setText(user.getFirstName());
        lastNameTF.setText(user.getLastName());
        addressTF.setText(user.getAddress());
        usernameTF.setText(user.getUsername());
        passwordTF.setText(user.getPassword());
        return user;
    }

    public User getEditFields(int userId) throws SQLException {
        User user = userDao.findOnId(userId);
        user.setId(userId);
        user.setFirstName(firstNameTF.getText());
        user.setLastName(lastNameTF.getText());
        user.setAddress(addressTF.getText());
        user.setUsername(usernameTF.getText());
        user.setPassword(passwordTF.getText());
        return user;
    }
}