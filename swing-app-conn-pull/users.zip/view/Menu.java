package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;

public class Menu extends JFrame {
    final JFrame frame = new JFrame("User table using Swing/AWT");
    final JPanel gui = new JPanel(new BorderLayout(5,5));
    JTable table;
    UsersModel model = new UsersModel();

    public Menu() throws SQLException {
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gui.setBackground(Color.white);
        JPanel headerPanel = new JPanel( new FlowLayout(FlowLayout.CENTER, 3,3));
        JLabel label = new JLabel("USERS PROGRAM");
        headerPanel.add(label);
        gui.add(headerPanel, BorderLayout.NORTH);

        JPanel menuPanel = new JPanel(new BorderLayout(4,4));
        JPanel buttonsPanel = new JPanel(new GridLayout(12, 4));
        buttonsPanel.setBackground(Color.DARK_GRAY);
        gui.add(buttonsPanel,BorderLayout.WEST);

        JButton usersList = new JButton("Users list");
        JButton createNew = new JButton("Create new");
        JButton deleteButton = new JButton(new RemoveAction());
        buttonsPanel.add( usersList);
        buttonsPanel.add( createNew);
        buttonsPanel.add(deleteButton);
        menuPanel.add( new JScrollPane(buttonsPanel), BorderLayout.CENTER );

        table = new JTable(model);
        new UsersModel();
        try {
            table.setAutoCreateRowSorter(true);
        } catch(Exception e) {
            e.printStackTrace();
        }

        JScrollPane tableScroll = new JScrollPane(table);
        Dimension tablePreferred = tableScroll.getPreferredSize();
        tableScroll.setPreferredSize(
                new Dimension(tablePreferred.width, tablePreferred.height/3) );

        final JPanel createPanel = new JPanel();
        createPanel.add(new CreateUserForm());
        final JPanel editPanel = new JPanel();

        usersList.addActionListener(e -> {
            if (createPanel.isShowing() || editPanel.isShowing()) {
                frame.remove(createPanel);
                frame.remove(editPanel);
                frame.add(tableScroll, BorderLayout.CENTER);
                deleteButton.setVisible(true);
                frame.revalidate();
                frame.repaint();
            }
        });
        createNew.addActionListener(e -> {
            if (editPanel.isShowing() || tableScroll.isShowing()) {
                frame.remove(tableScroll);
                frame.remove(editPanel);
                frame.add(createPanel);
                deleteButton.setVisible(false);
                frame.revalidate();
                frame.repaint();
            }
        });

        table.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent mouseEvent) {
                if (editPanel.getComponents().length > 0) {
                    editPanel.removeAll();
                    editPanel.revalidate();
                    editPanel.repaint();
                } else {
                    JTable table =(JTable) mouseEvent.getSource();
                    Point point = mouseEvent.getPoint();
                    int row = table.rowAtPoint(point);
                    if (mouseEvent.getClickCount() == 2 && table.getSelectedRow() != -1) {
                        int column = 0;
                        String value = table.getModel().getValueAt(row, column).toString();
                        int userId = Integer.parseInt(value);
                        frame.remove(tableScroll);
                        try {
                            editPanel.add(new EditUserForm(userId));
                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        frame.add(editPanel);
                        deleteButton.setVisible(false);
                        frame.revalidate();
                        frame.repaint();
                    }
                }
            }
        });
        gui.add(tableScroll);
        gui.add(menuPanel, BorderLayout.WEST);
        frame.setContentPane(gui);
        frame.pack();
        frame.setSize(900, 700);
        frame.setVisible(true);
        frame.addWindowListener(new MyWindowListener());
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    }

    private class RemoveAction extends AbstractAction {
        private RemoveAction() {
            super("Remove");
        }
        public void actionPerformed(ActionEvent e) {
            int selectedRow = table.getSelectedRow();
            if(selectedRow == -1) {
                JOptionPane.showMessageDialog(gui,"Select user!");
            } else {
                int column = 0;
                int row = table.getSelectedRow();
                String value = table.getModel().getValueAt(row, column).toString();
                int userId = Integer.parseInt(value);
                Object[] options = { "Yes", "No!" };
                int deleteChoice = JOptionPane.showOptionDialog(gui, "Do you wand delete user?",
                                "According", JOptionPane.YES_NO_OPTION,
                                JOptionPane.QUESTION_MESSAGE, null, options,
                                options[0]);
                if (deleteChoice == 0) {
                    try {
                        model.removeUser(selectedRow, userId, gui);
                    } catch (SQLException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        }
    }
}
