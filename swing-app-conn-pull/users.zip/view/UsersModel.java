package view;

import dao.UserDao;
import model.User;

import javax.swing.*;
import javax.swing.table.AbstractTableModel;
import java.sql.SQLException;
import java.util.List;

public class UsersModel extends AbstractTableModel {
    UserDao userDao = new UserDao();
    private List<User> users;
    String[] headers = {"user_id", "username", "password", "first name", "last name", "address"};

    public UsersModel() throws SQLException {
        super();
        //users = program.getAllUsers();
        users = this.userDao.findAll();
    }

    public void removeUser(int rowIndex, int userId, JPanel panel) throws SQLException {
        users.remove(rowIndex);
        userDao.delete(userId);
        fireTableRowsDeleted(rowIndex, rowIndex);
    }

    public int getRowCount() {
        return users.size();
    }

    public int getColumnCount() {
        return headers.length;
    }

    public String getColumnName(int columnIndex) {
        return headers[columnIndex];
    }

    public Object getValueAt(int rowIndex, int columnIndex) {
        switch(columnIndex){
            case 0:
                return users.get(rowIndex).getId();
            case 1:
                return users.get(rowIndex).getUsername();
            case 2:
                return users.get(rowIndex).getPassword();
            case 3:
                return users.get(rowIndex).getFirstName();
            case 4:
                return users.get(rowIndex).getLastName();
            case 5:
                return users.get(rowIndex).getAddress();
            default:
                return null;
        }
    }
}
